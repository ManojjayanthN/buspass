
	<div class="copy-right"> 
		<div class="container">
		<div data-elementor-type="footer" data-elementor-id="1680" class="elementor elementor-1680 elementor-location-footer" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-f22359a elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default" data-id="f22359a" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}" style="width: 1213px; left: 0px;">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4428fc6" data-id="4428fc6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-bac3ee1 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="bac3ee1" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-135cc1d" data-id="135cc1d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-187a9d6 elementor-widget elementor-widget-heading" data-id="187a9d6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">REACH US</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b7924b7 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="b7924b7" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.19.0 - 07-02-2024 */
.elementor-widget-divider{--divider-border-style:none;--divider-border-width:10px;--divider-color:#0c0d0e;--divider-icon-size:10px;--divider-element-spacing:10px;--divider-pattern-height:24px;--divider-pattern-size:20px;--divider-pattern-url:none;--divider-pattern-repeat:repeat-x}.elementor-widget-divider .elementor-divider{display:flex}.elementor-widget-divider .elementor-divider__text{font-size:15px;line-height:1;max-width:95%}.elementor-widget-divider .elementor-divider__element{margin:0 var(--divider-element-spacing);flex-shrink:0}.elementor-widget-divider .elementor-icon{font-size:var(--divider-icon-size)}.elementor-widget-divider .elementor-divider-separator{display:flex;margin:0;direction:ltr}.elementor-widget-divider--view-line_icon .elementor-divider-separator,.elementor-widget-divider--view-line_text .elementor-divider-separator{align-items:center}.elementor-widget-divider--view-line_icon .elementor-divider-separator:after,.elementor-widget-divider--view-line_icon .elementor-divider-separator:before,.elementor-widget-divider--view-line_text .elementor-divider-separator:after,.elementor-widget-divider--view-line_text .elementor-divider-separator:before{display:block;content:"";border-block-end:0;flex-grow:1;border-block-start:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-left .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-left .elementor-divider__element{margin-left:0}.elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-right .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-right .elementor-divider__element{margin-right:0}.elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-start .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-start .elementor-divider__element{margin-inline-start:0}.elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-end .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-end .elementor-divider__element{margin-inline-end:0}.elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator{border-block-start:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--separator-type-pattern{--divider-border-style:none}.elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,.elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator{width:100%;min-height:var(--divider-pattern-height);-webkit-mask-size:var(--divider-pattern-size) 100%;mask-size:var(--divider-pattern-size) 100%;-webkit-mask-repeat:var(--divider-pattern-repeat);mask-repeat:var(--divider-pattern-repeat);background-color:var(--divider-color);-webkit-mask-image:var(--divider-pattern-url);mask-image:var(--divider-pattern-url)}.elementor-widget-divider--no-spacing{--divider-pattern-size:auto}.elementor-widget-divider--bg-round{--divider-pattern-repeat:round}.rtl .elementor-widget-divider .elementor-divider__text{direction:rtl}.e-con-inner>.elementor-widget-divider,.e-con>.elementor-widget-divider{width:var(--container-widget-width,100%);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-865ecc5 elementor-widget elementor-widget-html" data-id="865ecc5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3881.990699565929!2d77.7258225752858!3d13.35085430644963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae16773c548eed%3A0xb9434aad7474e7df!2sNagarjuna%20College%20Of%20Engineering%20%26%20Technology!5e0!3m2!1sen!2sin!4v1685095693029!5m2!1sen!2sin" width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" data-gtm-yt-inspected-7="true"></iframe>		</div>
				</div>
				<div class="elementor-element elementor-element-5bc1a2d elementor-widget elementor-widget-heading" data-id="5bc1a2d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			
			<h2 class="elementor-heading-title elementor-size-default">ABOUT</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-8baea60 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="8baea60" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-3294bd0 elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="3294bd0" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;vertical&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;<i class=\&quot;fas fa-caret-down\&quot;><\/i>&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-vertical e--pointer-none">
				<ul id="menu-1-3294bd0" class="elementor-nav-menu sm-vertical" data-smartmenus-id="17078818218784148"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5741 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/samashti/" class="elementor-item">Samashti</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1650 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/gallery/" class="elementor-item">Gallery</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1652 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/02/NCET_Bus_Route_Details.pdf" class="elementor-item">Transportation</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1653 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/blog/" class="elementor-item">Blogs</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1658 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="#" class="elementor-item elementor-item-anchor">Prospectus</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1802 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/monthly-reports/" class="elementor-item">Monthly Reports</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3661 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/alumni/" class="elementor-item">Alumni</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7929 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/iic-2/" class="elementor-item">IIC</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7958 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/nisp-2/" class="elementor-item">NISP</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4434 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/nirf/" class="elementor-item">NIRF</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7880 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/01/Youthfestival-report-NCET.pdf" class="elementor-item">Yuvothsava</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7895 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/02/Anti-Ragging-Documents-Updated.pdf" class="elementor-item">Anti Ragging Policy</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
					<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true" style="--menu-height: 0;">
				<ul id="menu-2-3294bd0" class="elementor-nav-menu sm-vertical" data-smartmenus-id="17078818218793923"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5741 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/samashti/" class="elementor-item" tabindex="-1">Samashti</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1650 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/gallery/" class="elementor-item" tabindex="-1">Gallery</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1652 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/02/NCET_Bus_Route_Details.pdf" class="elementor-item" tabindex="-1">Transportation</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1653 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/blog/" class="elementor-item" tabindex="-1">Blogs</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1658 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="#" class="elementor-item elementor-item-anchor" tabindex="-1">Prospectus</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1802 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/monthly-reports/" class="elementor-item" tabindex="-1">Monthly Reports</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3661 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/alumni/" class="elementor-item" tabindex="-1">Alumni</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7929 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/iic-2/" class="elementor-item" tabindex="-1">IIC</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7958 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/nisp-2/" class="elementor-item" tabindex="-1">NISP</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4434 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/nirf/" class="elementor-item" tabindex="-1">NIRF</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7880 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/01/Youthfestival-report-NCET.pdf" class="elementor-item" tabindex="-1">Yuvothsava</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7895 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2024/02/Anti-Ragging-Documents-Updated.pdf" class="elementor-item" tabindex="-1">Anti Ragging Policy</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-ed19fea" data-id="ed19fea" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d27bd61 elementor-widget elementor-widget-heading" data-id="d27bd61" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">APPROVALS &amp; DISCLOSURES</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-ba01830 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ba01830" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-b1fb5fb elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="b1fb5fb" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;vertical&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;<i class=\&quot;fas fa-caret-down\&quot;><\/i>&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-vertical e--pointer-none">
				<ul id="menu-1-b1fb5fb" class="elementor-nav-menu sm-vertical" data-smartmenus-id="17078818218796392"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1659 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/mandatory-disclosures" class="elementor-item">Mandatory Disclosures</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3929 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/mandatory-disclosures" class="elementor-item">Approvals</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3996 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/autonomousregulations/" class="elementor-item">Autonomous Regulations</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1662 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/iqac/" class="elementor-item">IQAC</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1663 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="http://103.47.124.101/opac/" class="elementor-item">Library</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1664 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/SCSTandOBC.pdf" class="elementor-item">SC &amp; ST Committee</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1665 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://www.aicte-india.org/feedback/index.php" class="elementor-item">Online Student Feedback</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1666 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/SGRC-2023-24.pdf" class="elementor-item">Student Grievance Redressal Cell</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1673 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/NCET-Service-Manual.pdf" class="elementor-item">Service Manual</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5639 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/09/CICC2023-24.pdf" class="elementor-item">College Internal Complaints Committee(CICC)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5840 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/audit-reports/" class="elementor-item">Audit Reports</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
					<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true" style="--menu-height: 0;">
				<ul id="menu-2-b1fb5fb" class="elementor-nav-menu sm-vertical" data-smartmenus-id="17078818218792642"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1659 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/mandatory-disclosures" class="elementor-item" tabindex="-1">Mandatory Disclosures</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3929 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/mandatory-disclosures" class="elementor-item" tabindex="-1">Approvals</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3996 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/autonomousregulations/" class="elementor-item" tabindex="-1">Autonomous Regulations</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1662 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/iqac/" class="elementor-item" tabindex="-1">IQAC</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1663 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="http://103.47.124.101/opac/" class="elementor-item" tabindex="-1">Library</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1664 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/SCSTandOBC.pdf" class="elementor-item" tabindex="-1">SC &amp; ST Committee</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1665 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://www.aicte-india.org/feedback/index.php" class="elementor-item" tabindex="-1">Online Student Feedback</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1666 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/SGRC-2023-24.pdf" class="elementor-item" tabindex="-1">Student Grievance Redressal Cell</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1673 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/12/NCET-Service-Manual.pdf" class="elementor-item" tabindex="-1">Service Manual</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5639 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/wp-content/uploads/2023/09/CICC2023-24.pdf" class="elementor-item" tabindex="-1">College Internal Complaints Committee(CICC)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5840 tc-menu-item tc-menu-depth-0 tc-menu-align-left tc-menu-layout-default"><a href="https://ncet.co.in/audit-reports/" class="elementor-item" tabindex="-1">Audit Reports</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-18f7e22" data-id="18f7e22" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-544055f elementor-widget elementor-widget-heading" data-id="544055f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">COLLEGE ADDRESS</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-41cb381 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="41cb381" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-096ed83 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="096ed83" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://ncet.co.in/wp-content/uploads/elementor/css/custom-widget-icon-list.min.css?ver=1707191239">		
			<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-phone-alt"></i>						</span>
										<span class="elementor-icon-list-text">+91 8722992333</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-envelope"></i>						</span>
										<span class="elementor-icon-list-text">info@ncetmail.com</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-fax"></i>						</span>
										<span class="elementor-icon-list-text">08067462700</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-map-marker-alt"></i>						</span>
										<span class="elementor-icon-list-text">Nagarjuna College of Engineering &amp; Technology Beedaganahalli, Venkatagiri Kote, Post, Devanahalli, Bengaluru, Karnataka 562110</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-c1ec951 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="c1ec951" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-44c3031" data-id="44c3031" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-cca23e5 elementor-align-center elementor-widget elementor-widget-button" data-id="cca23e5" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://ncet.co.in/privacy-policy-2/">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Disclaimer &amp; Privacy Policy</span>
		</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-fa5a6cf elementor-widget elementor-widget-heading" data-id="fa5a6cf" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default"></p>	
			</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
			<p>© 2023 Manoj Jayanth N</p>
		</div> 
	</div> 
	<!-- //footer -->   
	